#include "Arduino.h"
#include "Encoder.h"
#include "MotorDriver.h"

Encoder::Encoder(int pinA, int pinB)
{
	pinMode(pinA, INPUT_PULLUP);
	pinMode(pinB, INPUT_PULLUP);
	_pinA = pinA;
	_pinB = pinB;
	_startTime = 0;
	_count = 0;
	_prevCount = 0;
	_ticks = 48;
	errorPrev = 0;
	errorSum = 0;
	controlTime = 0;
	kp = 0.05;
	kd = 0.0001;
	ki = 0.0001;
}

// reads out motor speed from encoder object
float Encoder::read(float time)
{
	float speed = (_count - _prevCount)/_ticks/((time- _startTime)*1000);
  updatePrevCount();
  updateTime(time);
	return speed;
}

// adds tick count
void Encoder::counts(bool pinA, bool pinB) // digitalRead of the pins as arguments
{
	if (pinB == LOW)
	{
		if (pinA == HIGH)
		{
			_count ++;
		}
		else
		{
			_count --;
		}
	}

	if (pinA == HIGH)
	{
		_count -- ;
	}
	else
	{
		_count ++;
	}
}

// updates time since last motor speed update
void Encoder::updateTime(float time)
{
	_startTime = time;
}

// updates count number since last motor speed update
void Encoder::updatePrevCount()
{
	_prevCount = _count;
}

// control algorithm for motor speed
float Encoder::speed_control(float error, float sum, float diff, float v, float dt) {
  v = error * kp + sum * ki + diff * kd/dt;
  return v;
}

// control algorithm for motor pwm 
float Encoder::control(float reference,float v, float dt) {
	float error =  reference - v;
	float errorDiff = error - errorPrev;
	errorSum = errorSum + error;
	// get new motor speed
	float motorSpeed =  error* kp + errorDiff * kd / dt +  errorSum * ki *dt ;

	controlTime = time;
	return motorSpeed;
}
