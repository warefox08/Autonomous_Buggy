#ifndef Encoder_h
#define Encoder_h

class Encoder
{
	public:
	Encoder(int pinA, int pinB);
 // sensor(int pin1,int pin2, int pin3, int pin4, int pin5, int pin6);
	float read(float time);
	void add(bool pinA, bool pinB);
	void updateTime(float time);
	void updatePrevCount();
  void counts(bool pinA, bool pinB);
  float control(float reference,float v, float dt);
  float speed_control(float error, float sum, float diff, float v, float dt);

    int _pin1;
    int _pin2;
    int _pin3;
    int _pin4;
    int _pin5;
    int _pin6;
    int _pinA;
    int _pinB;
    float _startTime;
    int _count;
    int _prevCount;
    int _ticks ;
    float errorPrev= 0;
    float errorSum= 0;
    float controlTime;
    float ki;
    float kd;
    float kp;
};

#endif
