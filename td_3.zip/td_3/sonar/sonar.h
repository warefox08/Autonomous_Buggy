#ifndef Sonar_h
#define Sonar_h

class Sonar {
  static volatile int current_pulseL;
  static volatile int current_pulseR;
  public:
	static void rchannelA();
  static void rchannelB();
  static void lchannelA();
  static void lchannelB();
	Sonar(int pinA, int pinB);
	float read(float time);
	void add(bool pinA, bool pinB);
	void updateTime(float time);
	void updatePrevCount();
    	float control(float speed, float time);
	float getSpeedL();
      	float getSpeedR();
      	void updateValues();
void run();
void brake(int time);
void left(int time);
void spin_left(int time);
void right(int time) ;
void spin_right(int time);
void back(int time);
void Distance_test();
 
    int _pinA;
    int _pinB;
    float _startTime;
    int _count;
    int _prevCount;
    int _ticks ;
    float errorPrev;
    float errorSum;
    float controlTime;
    float ki;
    float kd;
    float kp;
    float mindist;
    float dist_sonar;
};

#endif
